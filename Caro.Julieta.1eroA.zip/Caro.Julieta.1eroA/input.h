#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

int getInt(int* input, char mensaje[], char eMensaje[], int minimo, int maximo);

int getFloat(float* input, char mensaje[], char eMensaje[], int minimo, int maximo);

int getChar(char* input, char mensaje[], char eMensaje[], char minimo, char maximo);

int getString(char* input, char mensaje[], char eMensaje[], int minimo, int maximo);

int getCharSexo(char* input, char mensaje[], char eMensaje[]);

